

CS 574 - Lab 1
Tanmay Gore - tgore03@iastate.edu


Process to compile the code

1. Extract the NaiveBayesClassifier-Tanmay Gore.zip.
2. Enter the NaiveBayesClassifier-Tanmay Gore folder
3. Open command prompt here.
4. Execute following commands

	javac NaiveBayesTG.java
	java NaiveBayesTG vocabulary.txt map.csv train_label.csv 	train_data.csv test_label.csv test_data.csv

5. Obtain the results.