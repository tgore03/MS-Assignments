CS 574 - Lab3
Tanmay gore
tgore03@iastate.edu


Running the program:
1. Extract the zip file
2. Right click on lab3.py
3. Edit with IDLE
4. Run -> Run Module


How to generate Experimental resutlts:
1. In the main() method, change the values of parameter variables based on the parameters of each experiment specied in PDF file (included in the zip folder). 


2. There are two methods:
	nn_model() - For Feed Forward Neural Network
	cnn_model()- For Convoluted Neural Network

3. The same parameters are used for both the methods
