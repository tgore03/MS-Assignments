

Cs 574 - Lab 4
Tanmay Gore
tgore03@iastate.edu



Steps to reproduce the experiment:
1. Right click on lab4.py -> edit with IDLE
2. Run -> Run Module

3. To test on the experimental values used, just update the hyper-parameter values with the values to be tested and run the program again.

